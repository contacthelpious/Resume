'use client';

import { LandingPageContent } from '@/components/landing-page';

export default function Home() {
  // The main layout is handled in the component for better organization
  return <LandingPageContent />;
}
