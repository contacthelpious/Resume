export const firebaseConfig = {
  "projectId": "studio-6077940297-f3412",
  "appId": "1:907929550103:web:28f747bf01e71234198b52",
  "apiKey": "AIzaSyCxngbSRBbHhx7oNLJh-u74S1TArm0vd38",
  "authDomain": "studio-6077940297-f3412.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "907929550103"
};
